﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace CPU_Scheduel
{

    class Process
    {

        string name;
        int timeArrived, timeEnded, timeInCPU, duration, priority, timeLeft;
        public bool colorSet;
        public Color color;

        public Process() { }

        public Process(string name, int timeArr, int dur, int prior = -1)
        {
            this.name = name;
            this.timeArrived = timeArr;
            this.duration = dur;
            this.priority = prior;
            this.timeLeft = dur;
            this.colorSet = false;
            this.timeInCPU = 0;
        }

        public string get_name()
        {
            return name;
        }

        public int get_timeArrived()
        {
            return timeArrived;
        }

        public int get_duration()
        {
            return duration;
        }

        public int get_priority()
        {
            return priority;
        }

        public void set_timeLeft(int time)
        {
            this.timeLeft = time;
        }

        public void dec_timeLeft()
        {
            this.timeLeft--;
        }

        public int get_timeLeft()
        {
            return timeLeft;
        }

        public int get_timeEnded()
        {
            return timeEnded;
        }

        public void set_timeEnded(int t)
        {
            this.timeEnded = t;
        }

        public int get_timeInCPU()
        {
            return timeInCPU;
        }

        public void inc_timeInCPU(int t)
        {
            this.timeInCPU += t;
        }

    }

    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
