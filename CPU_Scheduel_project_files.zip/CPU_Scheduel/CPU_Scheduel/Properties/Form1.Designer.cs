﻿namespace CPU_Scheduel
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.schedulTypeBox = new System.Windows.Forms.ComboBox();
            this.premGroup = new System.Windows.Forms.GroupBox();
            this.nonPremRadio = new System.Windows.Forms.RadioButton();
            this.premRadio = new System.Windows.Forms.RadioButton();
            this.processGroup = new System.Windows.Forms.GroupBox();
            this.startButton = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.priorityGroup = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.priorityList = new System.Windows.Forms.ListBox();
            this.priorityTextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.addProcessButton = new System.Windows.Forms.Button();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.arrivedTextBox = new System.Windows.Forms.TextBox();
            this.durationTextBox = new System.Windows.Forms.TextBox();
            this.durationList = new System.Windows.Forms.ListBox();
            this.arrivedList = new System.Windows.Forms.ListBox();
            this.nameList = new System.Windows.Forms.ListBox();
            this.label7 = new System.Windows.Forms.Label();
            this.CPUBurstTextBox = new System.Windows.Forms.TextBox();
            this.CPUBurstGroup = new System.Windows.Forms.GroupBox();
            this.clearButton = new System.Windows.Forms.Button();
            this.premGroup.SuspendLayout();
            this.processGroup.SuspendLayout();
            this.priorityGroup.SuspendLayout();
            this.CPUBurstGroup.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Scheduler type:";
            // 
            // schedulTypeBox
            // 
            this.schedulTypeBox.FormattingEnabled = true;
            this.schedulTypeBox.Items.AddRange(new object[] {
            "FCFS",
            "SJF",
            "Priority",
            "Round Robin"});
            this.schedulTypeBox.Location = new System.Drawing.Point(16, 33);
            this.schedulTypeBox.Name = "schedulTypeBox";
            this.schedulTypeBox.Size = new System.Drawing.Size(121, 21);
            this.schedulTypeBox.TabIndex = 1;
            this.schedulTypeBox.Text = "Choose type";
            this.schedulTypeBox.SelectedIndexChanged += new System.EventHandler(this.schedulTypeBox_SelectedIndexChanged);
            this.schedulTypeBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.schedulTypeBox_KeyPress);
            // 
            // premGroup
            // 
            this.premGroup.Controls.Add(this.nonPremRadio);
            this.premGroup.Controls.Add(this.premRadio);
            this.premGroup.Location = new System.Drawing.Point(143, 26);
            this.premGroup.Name = "premGroup";
            this.premGroup.Size = new System.Drawing.Size(193, 28);
            this.premGroup.TabIndex = 2;
            this.premGroup.TabStop = false;
            this.premGroup.Visible = false;
            // 
            // nonPremRadio
            // 
            this.nonPremRadio.AutoSize = true;
            this.nonPremRadio.Location = new System.Drawing.Point(90, 8);
            this.nonPremRadio.Name = "nonPremRadio";
            this.nonPremRadio.Size = new System.Drawing.Size(101, 17);
            this.nonPremRadio.TabIndex = 1;
            this.nonPremRadio.Text = "Non Preemptive";
            this.nonPremRadio.UseVisualStyleBackColor = true;
            this.nonPremRadio.CheckedChanged += new System.EventHandler(this.nonPremRadio_CheckedChanged);
            // 
            // premRadio
            // 
            this.premRadio.AutoSize = true;
            this.premRadio.Checked = true;
            this.premRadio.Location = new System.Drawing.Point(6, 8);
            this.premRadio.Name = "premRadio";
            this.premRadio.Size = new System.Drawing.Size(78, 17);
            this.premRadio.TabIndex = 0;
            this.premRadio.TabStop = true;
            this.premRadio.Text = "Preemptive";
            this.premRadio.UseVisualStyleBackColor = true;
            this.premRadio.CheckedChanged += new System.EventHandler(this.premRadio_CheckedChanged);
            // 
            // processGroup
            // 
            this.processGroup.Controls.Add(this.clearButton);
            this.processGroup.Controls.Add(this.startButton);
            this.processGroup.Controls.Add(this.label6);
            this.processGroup.Controls.Add(this.priorityGroup);
            this.processGroup.Controls.Add(this.label4);
            this.processGroup.Controls.Add(this.label3);
            this.processGroup.Controls.Add(this.label2);
            this.processGroup.Controls.Add(this.addProcessButton);
            this.processGroup.Controls.Add(this.nameTextBox);
            this.processGroup.Controls.Add(this.arrivedTextBox);
            this.processGroup.Controls.Add(this.durationTextBox);
            this.processGroup.Controls.Add(this.durationList);
            this.processGroup.Controls.Add(this.arrivedList);
            this.processGroup.Controls.Add(this.nameList);
            this.processGroup.Location = new System.Drawing.Point(16, 60);
            this.processGroup.Name = "processGroup";
            this.processGroup.Size = new System.Drawing.Size(540, 300);
            this.processGroup.TabIndex = 3;
            this.processGroup.TabStop = false;
            this.processGroup.Visible = false;
            // 
            // startButton
            // 
            this.startButton.Location = new System.Drawing.Point(217, 271);
            this.startButton.Name = "startButton";
            this.startButton.Size = new System.Drawing.Size(75, 23);
            this.startButton.TabIndex = 4;
            this.startButton.Text = "Start";
            this.startButton.UseVisualStyleBackColor = true;
            this.startButton.Click += new System.EventHandler(this.startButton_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(10, 152);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(66, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "Add process";
            // 
            // priorityGroup
            // 
            this.priorityGroup.Controls.Add(this.label5);
            this.priorityGroup.Controls.Add(this.priorityList);
            this.priorityGroup.Controls.Add(this.priorityTextBox);
            this.priorityGroup.Location = new System.Drawing.Point(385, 0);
            this.priorityGroup.Name = "priorityGroup";
            this.priorityGroup.Size = new System.Drawing.Size(155, 300);
            this.priorityGroup.TabIndex = 11;
            this.priorityGroup.TabStop = false;
            this.priorityGroup.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 17);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Priority:";
            // 
            // priorityList
            // 
            this.priorityList.Enabled = false;
            this.priorityList.FormattingEnabled = true;
            this.priorityList.Location = new System.Drawing.Point(6, 36);
            this.priorityList.Name = "priorityList";
            this.priorityList.Size = new System.Drawing.Size(120, 95);
            this.priorityList.TabIndex = 6;
            // 
            // priorityTextBox
            // 
            this.priorityTextBox.Location = new System.Drawing.Point(6, 171);
            this.priorityTextBox.Name = "priorityTextBox";
            this.priorityTextBox.Size = new System.Drawing.Size(117, 20);
            this.priorityTextBox.TabIndex = 5;
            this.priorityTextBox.Text = "Priority";
            this.priorityTextBox.Enter += new System.EventHandler(this.priorityTextBox_Enter);
            this.priorityTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.priorityTextBox_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(259, 17);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Duration:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(133, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Arrived:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Name:";
            // 
            // addProcessButton
            // 
            this.addProcessButton.Location = new System.Drawing.Point(178, 226);
            this.addProcessButton.Name = "addProcessButton";
            this.addProcessButton.Size = new System.Drawing.Size(75, 23);
            this.addProcessButton.TabIndex = 7;
            this.addProcessButton.Text = "Add";
            this.addProcessButton.UseVisualStyleBackColor = true;
            this.addProcessButton.Click += new System.EventHandler(this.addProcessButton_Click);
            // 
            // nameTextBox
            // 
            this.nameTextBox.Location = new System.Drawing.Point(7, 171);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(120, 20);
            this.nameTextBox.TabIndex = 6;
            this.nameTextBox.Text = "Process name";
            this.nameTextBox.Enter += new System.EventHandler(this.nameTextBox_Enter);
            // 
            // arrivedTextBox
            // 
            this.arrivedTextBox.Location = new System.Drawing.Point(133, 171);
            this.arrivedTextBox.Name = "arrivedTextBox";
            this.arrivedTextBox.Size = new System.Drawing.Size(123, 20);
            this.arrivedTextBox.TabIndex = 5;
            this.arrivedTextBox.Text = "Time arrived";
            this.arrivedTextBox.Enter += new System.EventHandler(this.arrivedTextBox_Enter);
            this.arrivedTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.arrivedTextBox_KeyPress);
            // 
            // durationTextBox
            // 
            this.durationTextBox.Location = new System.Drawing.Point(262, 171);
            this.durationTextBox.Name = "durationTextBox";
            this.durationTextBox.Size = new System.Drawing.Size(117, 20);
            this.durationTextBox.TabIndex = 4;
            this.durationTextBox.Text = "Duration";
            this.durationTextBox.Enter += new System.EventHandler(this.durationTextBox_Enter);
            this.durationTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.durationTextBox_KeyPress);
            // 
            // durationList
            // 
            this.durationList.Enabled = false;
            this.durationList.FormattingEnabled = true;
            this.durationList.Location = new System.Drawing.Point(259, 36);
            this.durationList.Name = "durationList";
            this.durationList.Size = new System.Drawing.Size(120, 95);
            this.durationList.TabIndex = 3;
            // 
            // arrivedList
            // 
            this.arrivedList.Enabled = false;
            this.arrivedList.FormattingEnabled = true;
            this.arrivedList.Location = new System.Drawing.Point(133, 36);
            this.arrivedList.Name = "arrivedList";
            this.arrivedList.Size = new System.Drawing.Size(120, 95);
            this.arrivedList.TabIndex = 2;
            // 
            // nameList
            // 
            this.nameList.Enabled = false;
            this.nameList.FormattingEnabled = true;
            this.nameList.Location = new System.Drawing.Point(7, 36);
            this.nameList.Name = "nameList";
            this.nameList.Size = new System.Drawing.Size(120, 95);
            this.nameList.TabIndex = 0;
            this.nameList.Tag = "";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 13);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(59, 13);
            this.label7.TabIndex = 4;
            this.label7.Text = "CPU Burst:";
            // 
            // CPUBurstTextBox
            // 
            this.CPUBurstTextBox.Location = new System.Drawing.Point(4, 31);
            this.CPUBurstTextBox.Name = "CPUBurstTextBox";
            this.CPUBurstTextBox.Size = new System.Drawing.Size(71, 20);
            this.CPUBurstTextBox.TabIndex = 5;
            this.CPUBurstTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.CPUBurstTextBox_KeyPress);
            // 
            // CPUBurstGroup
            // 
            this.CPUBurstGroup.Controls.Add(this.label7);
            this.CPUBurstGroup.Controls.Add(this.CPUBurstTextBox);
            this.CPUBurstGroup.Location = new System.Drawing.Point(342, 2);
            this.CPUBurstGroup.Name = "CPUBurstGroup";
            this.CPUBurstGroup.Size = new System.Drawing.Size(88, 61);
            this.CPUBurstGroup.TabIndex = 6;
            this.CPUBurstGroup.TabStop = false;
            this.CPUBurstGroup.Visible = false;
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(262, 226);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 13;
            this.clearButton.Text = "Clear all";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(566, 376);
            this.Controls.Add(this.CPUBurstGroup);
            this.Controls.Add(this.processGroup);
            this.Controls.Add(this.premGroup);
            this.Controls.Add(this.schedulTypeBox);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "CPU Schedueler";
            this.premGroup.ResumeLayout(false);
            this.premGroup.PerformLayout();
            this.processGroup.ResumeLayout(false);
            this.processGroup.PerformLayout();
            this.priorityGroup.ResumeLayout(false);
            this.priorityGroup.PerformLayout();
            this.CPUBurstGroup.ResumeLayout(false);
            this.CPUBurstGroup.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox schedulTypeBox;
        private System.Windows.Forms.GroupBox premGroup;
        private System.Windows.Forms.RadioButton nonPremRadio;
        private System.Windows.Forms.RadioButton premRadio;
        private System.Windows.Forms.GroupBox processGroup;
        private System.Windows.Forms.GroupBox priorityGroup;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ListBox priorityList;
        private System.Windows.Forms.TextBox priorityTextBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button addProcessButton;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.TextBox arrivedTextBox;
        private System.Windows.Forms.TextBox durationTextBox;
        private System.Windows.Forms.ListBox durationList;
        private System.Windows.Forms.ListBox arrivedList;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ListBox nameList;
        private System.Windows.Forms.Button startButton;
        private System.Windows.Forms.TextBox CPUBurstTextBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox CPUBurstGroup;
        private System.Windows.Forms.Button clearButton;
    }
}

