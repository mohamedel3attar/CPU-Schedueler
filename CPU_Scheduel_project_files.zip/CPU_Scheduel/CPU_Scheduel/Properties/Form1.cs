﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;



namespace CPU_Scheduel
{
    public partial class Form1 : Form
    {

        string schedType;
        bool preem = true, priority;
        int numOfProcess = 0, totalTime = 0, CPUBurst = 0;
        List<Process> processesList = new List<Process>();
        List<Process> processesTemp = new List<Process>();
        List<Rectangle> rects = new List<Rectangle>();
        Form2 myform = new Form2();
        Chart mychart = new Chart();
        ChartArea chartA = new ChartArea();
        int emptyIndex = 0, nameIndex = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void schedulTypeBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            processesList.Clear();
            nameList.Items.Clear();
            arrivedList.Items.Clear();
            durationList.Items.Clear();
            priorityList.Items.Clear();
            numOfProcess = 0;
            processGroup.Visible = true;
            schedType = schedulTypeBox.Text;
            if (schedType == "SJF" || schedType == "Priority")
            {
                premGroup.Visible = true;
            }
            else
            {
                premGroup.Visible = false;
            }
            if (schedType == "Priority")
            {
                priorityGroup.Visible = true;
                priority = true;
            }
            else
            {
                priorityGroup.Visible = false;
                priority = false;
            }
            if (schedType == "Round Robin")
            {
                CPUBurstGroup.Visible = true;
            }
            else
            {
                CPUBurstGroup.Visible = false;
            }
        }

        private void premRadio_CheckedChanged(object sender, EventArgs e)
        {
            preem = premRadio.Checked;
        }

        private void nonPremRadio_CheckedChanged(object sender, EventArgs e)
        {
            preem = !nonPremRadio.Checked;
        }

        private void nameTextBox_Enter(object sender, EventArgs e)
        {
            if (nameTextBox.Text == "Process name")
                nameTextBox.Clear();
        }

        private void arrivedTextBox_Enter(object sender, EventArgs e)
        {
            if (arrivedTextBox.Text == "Time arrived")
                arrivedTextBox.Clear();
        }

        private void durationTextBox_Enter(object sender, EventArgs e)
        {
            if (durationTextBox.Text == "Duration")
                durationTextBox.Clear();
        }

        private void priorityTextBox_Enter(object sender, EventArgs e)
        {
            if (priorityTextBox.Text == "Priority")
                priorityTextBox.Clear();
        }

        private void arrivedTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void durationTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void priorityTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void schedulTypeBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void CPUBurstTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void numOfProcessTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void addProcessButton_Click(object sender, EventArgs e)
        {
            if (nameTextBox.Text == "" || nameTextBox.Text == "Process name") MessageBox.Show("Please enter process name");
            else if (arrivedTextBox.Text == "" || arrivedTextBox.Text == "Time arrived") MessageBox.Show("Please enter arriving time");
            else if (durationTextBox.Text == "" || durationTextBox.Text == "Duration" || durationTextBox.Text == "0") MessageBox.Show("Please enter duration");
            else if ((priorityTextBox.Text == "" || priorityTextBox.Text == "Priority") && priority == true) MessageBox.Show("Please enter priority");
            else
            {
                nameList.Items.Add(nameTextBox.Text);
                arrivedList.Items.Add(arrivedTextBox.Text);
                durationList.Items.Add(durationTextBox.Text);
                if (priority) priorityList.Items.Add(priorityTextBox.Text);
                Process temp;
                if(priority)
                    temp = new Process(nameTextBox.Text, Int32.Parse(arrivedTextBox.Text), Int32.Parse(durationTextBox.Text), Int32.Parse(priorityTextBox.Text));
                else
                    temp = new Process(nameTextBox.Text, Int32.Parse(arrivedTextBox.Text), Int32.Parse(durationTextBox.Text));
                processesList.Add(temp);
                numOfProcess++;
                totalTime += Int32.Parse(durationTextBox.Text);
                nameTextBox.Clear();
                arrivedTextBox.Clear();
                durationTextBox.Clear();
                if (priority) priorityTextBox.Clear();
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            processesList.Clear();
            nameList.Items.Clear();
            arrivedList.Items.Clear();
            durationList.Items.Clear();
            priorityList.Items.Clear();
            numOfProcess = 0;
        }

        /*private void startButton_Click(object sender, EventArgs e)
        {
            if (numOfProcess == 0) MessageBox.Show("Please add process");
            else
            {
                processesList = processesList.OrderBy(o => o.get_timeArrived()).ThenBy(o => o.get_duration()).ToList();
                int width = Screen.PrimaryScreen.Bounds.Width;
                myform.Width = width;
                myform.Height = 300;
                width -= 40;
                int initialX = 10;
                foreach (Process item in processesList)
                {
                    float rect_width = ((float)item.get_duration() / totalTime) * width;
                    rects.Add(new Rectangle(initialX, 100, (int)rect_width, 30));
                    addLabel(initialX + (int)(rect_width / 2), 150, item.get_name(), myform);
                    initialX += (int)rect_width;
                    chart1.Series.Add(item.get_name());
                    chart1.Series[item.get_name()].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.StackedBar;
                    chart1.Series[item.get_name()].Points.AddXY(1, item.get_duration());
                    chart1.Series[item.get_name()].ChartArea = "ChartArea1";
                    
                }

                //drawRects();
                //myform.Show();
                
                
            }
        }*/

        private void startButton_Click(object sender, EventArgs e)
        {
            if (numOfProcess == 0) MessageBox.Show("Please add process");
            else
            {
                chartA.Dispose();
                mychart.Dispose();
                myform.Dispose();
                emptyIndex = 0;
                nameIndex = 0;
                myform = new Form2();
                mychart = new Chart();
                chartA = new ChartArea();
                if (priority)
                {
                    processesList = processesList.OrderBy(o => o.get_timeArrived()).ThenBy(o => o.get_priority()).ToList();
                }
                else
                {
                    processesList = processesList.OrderBy(o => o.get_timeArrived()).ThenBy(o => o.get_duration()).ToList();
                }
                int width = Screen.PrimaryScreen.Bounds.Width;
                myform.Width = width;
                myform.Height = 500;
                mychart.Height = 250;
                mychart.Width = width;
                mychart.Visible = true;
                mychart.ChartAreas.Add(chartA);
                mychart.Legends.Add("mylegend");
                if (schedType == "FCFS") FCFS();
                else if (schedType == "SJF") SJF();
                else if (schedType == "Priority") priorityFn();
                else if (schedType == "Round Robin")
                {
                    if (CPUBurstTextBox.Text == "" || CPUBurstTextBox.Text == "0")
                    {
                        MessageBox.Show("Please add CPU burst");
                        return;
                    }
                    roundRobin();
                }
                
                Label avgWaitingLabel = new Label();
                avgWaitingLabel.AutoSize = true;
                avgWaitingLabel.Text = "Average waiting time = " + calcAvgWaiting().ToString();
                avgWaitingLabel.Location = new Point(30, 300);
                myform.Controls.Add(mychart);
                myform.Controls.Add(avgWaitingLabel);
                myform.Show();
            }
        }

        private void addLabel(int x, int y, string text, Form2 myform)
        {
            Label namelabel = new Label();
            namelabel.Location = new Point(x, y);
            namelabel.Text = text;
            namelabel.AutoSize = true;
            namelabel.Location = new Point(x - namelabel.PreferredWidth, y);
            myform.Controls.Add(namelabel);
        }

        private void drawRects() //draw rectangles List
        {
            foreach (Rectangle r in rects)
            {
                myform.Paint += (o, ee) =>
                {
                    Graphics g = ee.Graphics;
                    using (Pen selPen = new Pen(Color.Blue))
                    {
                        g.DrawRectangle(selPen, r);

                    }

                };
            }
        }

        private void drawRect(Rectangle r) //draws a single rectangle
        {
            myform.Paint += (o, ee) =>
            {
                Graphics g = ee.Graphics;
                using (Pen selPen = new Pen(Color.Blue))
                {
                    g.DrawRectangle(selPen, r);

                }

            };
        }

        private Process searchByArr(int arrTime)
        {
            foreach (Process p in processesList)
            {
                if (p.get_timeArrived() == arrTime)
                {
                    return p;
                }
            }
            return null;
        }

        private void addBar(Process p, int timeIn)
        {
            string name = p.get_name() + "_" + nameIndex;
            mychart.Series.Add(name);
            mychart.Series[name].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.StackedBar;
            mychart.Series[name].Points.AddXY(1, timeIn);
            if (p.colorSet == false)
            {
                mychart.ApplyPaletteColors();
                p.color = mychart.Series[name].Color;
                p.colorSet = true;
            }
            else
            {
                mychart.Series[name].Color = p.color;
            }
            mychart.Series[name].ChartArea = chartA.Name;
            nameIndex++;
        }

        private void addEmptyBar(int timeIn)
        {
            string name = "Empty_" + emptyIndex;
            mychart.Series.Add(name);
            mychart.Series[name].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.StackedBar;
            mychart.Series[name].Points.AddXY(1, timeIn);
            mychart.Series[name].Color = Color.White;
            mychart.Series[name].ChartArea = chartA.Name;
            emptyIndex++;
        }

        private void FCFS()
        {
            int currentTime = 0;
            foreach (Process p in processesList)
            {
                if (p.get_timeArrived() > currentTime)
                {
                    addEmptyBar(p.get_timeArrived() - currentTime);
                    currentTime += p.get_timeArrived() - currentTime;
                }
                addBar(p, p.get_duration());
                p.inc_timeInCPU(p.get_duration());
                currentTime += p.get_duration();
                p.set_timeEnded(currentTime);
            }
            processesTemp = processesList;
        }

        private void SJF()
        {
            int currentTime = 0, timeIn=0;
            Process shortest = processesList[0];
            if (preem)
            {
                while (true)
                {
                    foreach (Process p in processesList)
                    {
                        if (p.get_timeArrived() <= currentTime && p.get_timeLeft() < shortest.get_timeLeft())
                        {
                            addBar(shortest, timeIn);
                            shortest.inc_timeInCPU(timeIn);
                            shortest = p;
                            timeIn = 0;
                        }
                    }
                    shortest.dec_timeLeft();
                    timeIn++;
                    if (shortest.get_timeLeft() == 0)
                    {
                        addBar(shortest, timeIn);
                        shortest.inc_timeInCPU(timeIn);
                        shortest.set_timeEnded(currentTime + 1);
                        timeIn = 0;
                        processesTemp.Add(shortest);
                        processesList.Remove(shortest);
                        if (processesList.Count == 0) break;
                        if (processesList[0].get_timeArrived() > currentTime)
                        {
                            addEmptyBar(processesList[0].get_timeArrived() - (currentTime+1));
                            currentTime = processesList[0].get_timeArrived();
                        }
                        shortest = processesList[0];
                    }
                    currentTime++;
                }
            }
            else
            {
                foreach (Process p in processesList)
                {
                    if (p.get_timeArrived() > currentTime)
                    {
                        addEmptyBar(p.get_timeArrived() - currentTime);
                        currentTime += p.get_timeArrived() - currentTime;
                    }
                    addBar(p, p.get_duration());
                    p.inc_timeInCPU(p.get_duration());
                    currentTime += p.get_duration();
                    p.set_timeEnded(currentTime);
                }
                processesTemp = processesList;
            }
        }

        private void priorityFn()
        {
            int currentTime = 0, timeIn = 0;
            Process highestP = processesList[0];
            if (preem)
            {
                while (true)
                {
                    foreach (Process p in processesList)
                    {
                        if (p.get_timeArrived() <= currentTime && p.get_priority() < highestP.get_priority())
                        {
                            addBar(highestP, timeIn);
                            highestP.inc_timeInCPU(timeIn);
                            highestP = p;
                            timeIn = 0;
                        }
                    }
                    highestP.dec_timeLeft();
                    timeIn++;
                    if (highestP.get_timeLeft() == 0)
                    {
                        addBar(highestP, timeIn);
                        highestP.inc_timeInCPU(timeIn);
                        highestP.set_timeEnded(currentTime + 1);
                        timeIn = 0;
                        processesTemp.Add(highestP);
                        processesList.Remove(highestP);
                        if (processesList.Count == 0) break;
                        if (processesList[0].get_timeArrived() > currentTime)
                        {
                            addEmptyBar(processesList[0].get_timeArrived() - (currentTime + 1));
                            currentTime = processesList[0].get_timeArrived();
                        }
                        highestP = processesList[0];
                    }
                    currentTime++;
                }
            }
            else
            {
                foreach (Process p in processesList)
                {
                    if (p.get_timeArrived() > currentTime)
                    {
                        addEmptyBar(p.get_timeArrived() - currentTime);
                        currentTime += p.get_timeArrived() - currentTime;
                    }
                    addBar(p, p.get_duration());
                    p.inc_timeInCPU(p.get_duration());
                    currentTime += p.get_duration();
                    p.set_timeEnded(currentTime);
                }
                processesTemp = processesList;
            }
        }

        private void roundRobin()
        {
            CPUBurst = Int32.Parse(CPUBurstTextBox.Text);
            int currentTime = 0, ended = 0;
            while (ended != processesList.Count)
            {
                int i = 0;
                foreach (Process p in processesList)
                {
                    if (p.get_timeLeft() == 0) continue;
                    if (p.get_timeArrived() <= currentTime)
                    {
                        if (p.get_timeLeft() <= CPUBurst)
                        {
                            addBar(p, p.get_timeLeft());
                            currentTime += p.get_timeLeft();
                            p.inc_timeInCPU(p.get_timeLeft());
                            p.set_timeEnded(currentTime);
                            p.set_timeLeft(0);
                            ended++;
                            
                        }
                        else
                        {
                            addBar(p, CPUBurst);
                            p.inc_timeInCPU(CPUBurst);
                            p.set_timeLeft(p.get_timeLeft() - CPUBurst);
                            currentTime += CPUBurst;
                        }
                    }
                    else if(i == 0)
                    {
                        addEmptyBar(p.get_timeArrived() - currentTime);
                        currentTime += p.get_timeArrived() - currentTime;
                        break;
                    }
                    else
                    {
                        break;
                    }
                    i++;
                }
            }
            processesTemp = processesList;
        }

        private double calcAvgWaiting()
        {
            double totalTime = 0;
            foreach (Process p in processesTemp)
            {
                totalTime += (p.get_timeEnded() - p.get_timeArrived()) - p.get_timeInCPU();
            }
            return totalTime / numOfProcess;
        }

    }
}

//timeout - timearr - timeincpu